TOKEN = "1234:1234-1234" #токен-бота #https://t.me/BotFather

API_I = 1234 # userbot для автовыдачи звёзд
API_H ='1234' # userbot для автовыдачи звёзд
#api id api hasр - для автовыплат(юзербот) нужно будет аккаунт тг иметь, на нем должны быть звезды
#получить тут https://my.telegram.org/auth?to=apps


DONATE_PAY = 500 # цена доната в звездах тг
DONATE_TIME = 15 # время подписки доната

TELEGRAPH1 = "https://teletype.in"
TELEGRAPH2 = "https://teletype.in"

LINK_1 = "https://t.me/" # Основной канал
LINK_2 = "https://t.me/" # Чат
LINK_3 = "https://t.me/" # Выплаты
LINK_4 = "https://t.me/" # Стата Мини-игр
LINK_5 = "https://t.me/" # Пост с отзывами

USER_BOT = 'botuserneme' # username бота
SUP_LOGIN = "username" # username аккаунта выплат/саппорта

ADMIN_IDS = [1234, 12345] #id админов
ADMIN_IDD = 1234 # ID гл.админа

LINK_BOT = f"https://t.me/{USER_BOT}?start={ADMIN_IDD}" #ваша реферальная ссылка на бота

CHANEL_ID = -100 #канал выплат (общий)
NEWS_CHANEL_ID = -100 #новостной канал (общий)
WIN_CHANEL_ID = -100 #канал с выигрышами в мини-игре (общий)

LOG_CH_USER = -1001234 # канал логов новых пользователей (админский)
LOG_VER_USER = -1001234 # канал логов новых пользователей прошедших ОП (админский)
LOG_VIVOD_CHANEL = -1001234 # канал логов с выводами (админский)
#можно сделать все в ОДИН канал

GRAND_API_KEY = '1234' # временно нету
FLYER_API_KEY = '1234' # получить в https://t.me/FlyerServiceBot
REQUEST_API_KEY = '1234' #получить в https://t.me/subgram_officialbot
REQUEST_OP_DELAY_HOURS = 0 #нетрогать
REQUEST_OP_DELAY_MINUTES = 0 #нетрогать

REF_VIVOD_MIN = 15 # минимум рефов за неделю для вывода

TIME_CLICK_KD = 600 #кд на фарм звезд кликами в сек-ах

SHOW_MINI_GAMES_BUTTON = True # Или False, если кнопку мини-игр скрывать

MIN_GIFT= 1
MIN_GIFT_L = 1

MAX_GIFT = 2
MAX_GIFT_L = 2

MIN_REF_REWARD = 1
MAX_REF_REWARD =1 #Максимальная награда за реферала

MIN_REF_REWARD_X2 = 2
MAX_REF_REWARD_X2 = 2 #Максимальная награда за реферала во время счастливого часа

CLICK_MIN_REWARD = 0.10
CLICK_MAX_REWARD = 0.10 #Максимальная награда за клики

CLICK_MIN_REWARD_X2 = 0.20
CLICK_MAX_REWARD_X2 = 0.20 #Максимальная награда за клики во время счастливого часа

WIN_CHANCE = 1 #шанс победы в мини-игре